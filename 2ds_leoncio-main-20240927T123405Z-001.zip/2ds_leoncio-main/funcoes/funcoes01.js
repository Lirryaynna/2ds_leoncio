function ola(){
    console.log('Olá')
}
function olaPessoa(nome){
    console.log('Olá, ' + nome)
}

ola()
olaPessoa()