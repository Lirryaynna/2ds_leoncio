function calc(n1, n2){
    return n1 + n2
}
calc(2,5)
calc(10,5)